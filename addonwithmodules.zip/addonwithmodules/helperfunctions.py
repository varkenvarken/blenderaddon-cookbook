from mathutils import Vector

def myfunc(loc):
    """Silly demonstration function."""
    inc = Vector((1,0,0))
    return loc + inc
